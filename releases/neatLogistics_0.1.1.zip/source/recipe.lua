data:extend({
	{
		type = "recipe",
		name = "neat-logistic-chest-requester",
		enabled = false,
		ingredients = {
			{"logistic-chest-requester", 1},
			{"advanced-circuit", 1}
		},
		result = "neat-logistic-chest-requester"
	},
	{
		type = "recipe",
		name = "neat-smart-inserter",
		enabled = false,
		ingredients = {
			{"smart-inserter", 1},
			{"advanced-circuit", 1}
		},
		result = "neat-smart-inserter"
	},
	
})