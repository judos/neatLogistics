addTechnologyUnlocksRecipe("logistic-system","neat-logistic-chest-requester")
addTechnologyUnlocksRecipe("logistic-system","neat-smart-inserter")

